<?php
function getDashboard()
{
  echo "this is the dash!";

}

 ?>
<form class="" action="index.php" method="post">
  <input type="submit" name="logout" value="uitloggen!">
</form>
