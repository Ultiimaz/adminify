<?php
  include 'bootstrap.php';

    $database = database;
    $db = $database->getDatabase();
    $db = $database->sendQuery();
 ?>
